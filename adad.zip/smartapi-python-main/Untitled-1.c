#include <stdio.h>

int stringlen(char *str)
{
    int length = 0;
    while(str[length] != '\0')
    length++;
    return length;
}

int main(void){
    char a[100];
    printf("Enter text: ");
    scanf("%s", a);
    int b = stringlen(a);
    printf("Length: %d", b);
}