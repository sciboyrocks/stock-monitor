import tkinter as tk
import threading
import urllib.parse
import requests, json, os, sys
from SmartApi import SmartConnect #or from SmartApi.smartConnect import SmartConnect
import pyotp
from logzero import logger

webpage_url = "https://www.niftyindices.com/indices/equity/sectoral-indices"

db_indices = {} 
db_stocks = {} 
buying_indices = {}
selling_indices = {}
neutral_indices = {}
top_stocks = {} 
top_buying_stocks = {} # Contains elements as {Index : {stock : vol ratio}}
top_selling_stocks = {} # Contains elements as {Index : {stock : vol ratio}}

def get_index_data():
    try:
        r = requests.get('https://iislliveblob.niftyindices.com/jsonfiles/LiveIndicesWatch.json')
        r.raise_for_status()
        indexes = r.json()["data"]
    except Exception as e:
        print(f"\033[91mFailed to retrieve data of Indices, Error Message: \n \033[93m{e}\033[91m \033[0m")
        exit()

    for index in indexes:
        try:
            db_indices.update({index["indexName"] : float(index["percChange"])})
        except ValueError:
            continue

def get_top_indices():
    global db_indices
    displayed_indices = ['NIFTY FIN SERVICE',
                         'NIFTY FINSRV25 50',
                         'NIFTY FINSEREXBNK',
                         'NIFTY PVT BANK',
                         'NIFTY CONSR DURBL',
                         'NIFTY MS FIN SERV',
                         'NIFTY MIDSML HLTH',
                         'NIFTY MS IT TELCM',
                         'NIFTY 50',
                         'NIFTY BANK',
                         'NIFTY FMCG',
                         'NIFTY HEALTHCARE',
                         'NIFTY OIL AND GAS',
                         'NIFTY IT',
                         'NIFTY MEDIA',
                         'NIFTY METAL',
                         'NIFTY PHARMA',
                         'NIFTY PSU BANK',
                         'NIFTY REALTY',
                         "NIFTY AUTO",
                        ]


    needed_indices = {}
    for index in displayed_indices:
       if index in db_indices.keys():
           needed_indices[index] = db_indices[index]

    import copy
    db_indices = copy.deepcopy(needed_indices)
    del needed_indices

def generate_index_link(index_name):
    
    encoded_index = urllib.parse.quote(index_name)
    link = f"https://iislliveblob.niftyindices.com/jsonfiles/equitystockwatch/EquityStockWatch{encoded_index}.json?{{}}"
    return link

def get_stocks_info():
    global top_stocks
    for index in db_indices.keys():
        try:
            link = generate_index_link(index)
            r = requests.get(link)
            db_stocks.update({index : []})
            info = r.json()["data"]
        except Exception:
            print(f"\033[91mFailed to retrieve data for the stocks listed in the '{index}' index.\033[0m")
            root.quit()
            sys.exit()

        for i in range(len(info)):
            db_stocks[index].append([info[i]["symbol"], float(info[i]["trdVolM"]), float(info[i]["iislPercChange"])])
            top_stocks.update({info[i]["symbol"] : [float(info[i]["iislPercChange"]), float(info[i]["trdVolM"])]})

    top = []
    for stock in list(top_stocks.values()):
        if stock[0] not in top:
            top.append(stock[0])
    top.sort(reverse=True)
    top_stocks = {key: value for key, value in top_stocks.items() if value[0] in top[:3]}
    top_stocks = dict(sorted(top_stocks.items(), key=lambda item: item[1], reverse=True))
    del top

def determine_sector():
    global db_indices, buying_indices, selling_indices, neutral_indices
    for index, value in db_indices.items():
        if value > 0:
            buying_indices[index] = value
        elif value < 0:
            selling_indices[index] = value

        elif value == 0:
            neutral_indices[index] = value

    buying_indices = dict(sorted({k: v for k, v in buying_indices.items() if v <= 5}.items(), key=lambda item: item[1], reverse=True))
    selling_indices = dict(sorted({k: v for k, v in selling_indices.items() if abs(v) <= 5}.items(), key=lambda item: item[1]))
    
    top = list(buying_indices.values())[:2]
    buying_indices = {key: value for key, value in buying_indices.items() if value in top}
    global top_buying_stocks
    for index in buying_indices:
        top_buying_stocks.update({index : get_top_buying_stocks(index)})
    for key in top_buying_stocks:
        top_buying_stocks[key] = dict(sorted(top_buying_stocks[key].items(), key=lambda item: item[1], reverse=True))


    top = list(selling_indices.values())[:2]
    selling_indices = {key: value for key, value in selling_indices.items() if value in top}
    global top_selling_stocks
    top_selling_stocks = {}
    for index in selling_indices:
        top_selling_stocks.update({index : get_top_selling_stocks(index)})
    for key in top_selling_stocks:
        top_selling_stocks[key] = dict(sorted(top_selling_stocks[key].items(), key=lambda item: item[1], reverse=True))    
    del top

def get_top_buying_stocks(index):
    top = {}
    top_vol = []
    tops = []
    for stocks in db_stocks[index]:
        top_vol.append(stocks[1])
        top_vol.sort()
        for ratio in top_vol:
            if ratio not in tops:
                tops.append(ratio)
        tops = tops[:3]
    for stocks in db_stocks[index]:
        if stocks[1] in tops:
            top.update({stocks[0] : stocks[1]})
    del tops, top_vol
    return top

def get_top_selling_stocks(index):
    top = {}
    global top_vol, tops
    top_vol = []
    tops = []
    for stocks in db_stocks[index]:
        top_vol.append(stocks[1])
        for ratio in top_vol:
            if ratio not in tops:
                tops.append(ratio)
        tops.sort(reverse=True)
        tops = tops[:3]
    for stocks in db_stocks[index]:
        if stocks[1] in tops:
            top.update({stocks[0] : stocks[1]})
    #del tops, top_vol
    return top

def get_symbol_token(stock, cache_file="OpenAPIScripMaster.json"):
    if not os.path.exists(cache_file):
        url = 'https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json'
        response = requests.get(url)
        response.raise_for_status() 
        with open(cache_file, 'w') as f:
            json.dump(response.json(), f)
    
    with open(cache_file, 'r') as f:
        data = json.load(f)
    for entry in data:
        if entry["symbol"] == f"{stock}-EQ":
            return entry["token"]
    
    return None

def refresh_data():
    """Fetch and update the data every second."""
    # Use a separate thread to fetch and process data
    threading.Thread(target=fetch_and_process_data).start()

def fetch_and_process_data():
    """Fetch data, process it, and update the GUI."""
    get_index_data()
    get_top_indices()
    get_stocks_info()
    determine_sector()
    update_gui()


def update_gui():
    
    """Update the GUI with the latest data."""
    # Clear the frames
    for widget in buying_frame.winfo_children():
        widget.destroy()
    for widget in selling_frame.winfo_children():
        widget.destroy()

    # Update buying indices and stocks
    buying_label = tk.Label(buying_frame, text="Buying Indices and Stocks", bg="lightgreen", font=("Sabon", 16, "bold"))
    buying_label.pack(anchor=tk.N)
    for index, stocks in top_buying_stocks.items():
        index_label = tk.Label(buying_frame, text=f"{index} ({buying_indices[index]:.2f}%)", bg="lightgreen", font=("Sabon", 14))
        index_label.pack(anchor=tk.W, padx=5, pady=5)
        for stock, volume in stocks.items():
            stock_label_frame = tk.Frame(buying_frame, bg="lightgreen")
            stock_label_frame.pack(anchor=tk.W, padx=20, pady=5)
            stock_label = tk.Label(stock_label_frame, text=f"{stock}: {volume}M, ₹{find_stockprice(stock)} per share", bg="lightgreen", font=("Sabon", 12))
            stock_label.pack(side=tk.LEFT)
            buy_button = tk.Button(stock_label_frame, text="Buy", command=lambda s=stock: on_buy(s), font=("Sabon", 12), bg="green", fg="white")
            buy_button.pack(side=tk.LEFT, padx=10)

    # Update selling indices and stocks
    selling_label = tk.Label(selling_frame, text="Selling Indices and Stocks", bg="lightcoral", font=("Sabon", 16, "bold"))
    selling_label.pack(anchor=tk.N)
    for index, stocks in top_selling_stocks.items():
        index_label = tk.Label(selling_frame, text=f"{index} ({selling_indices[index]:.2f}%)", bg="lightcoral", font=("Sabon", 14))
        index_label.pack(anchor=tk.W, padx=5, pady=5)
        for stock, volume in stocks.items():
            stock_label_frame = tk.Frame(selling_frame, bg="lightcoral")
            stock_label_frame.pack(anchor=tk.W, padx=20, pady=5)
            stock_label = tk.Label(stock_label_frame, text=f"{stock}: {volume}M, ₹{find_stockprice(stock)} per share", bg="lightcoral", font=("Sabon", 12))
            stock_label.pack(side=tk.LEFT)
            sell_button = tk.Button(stock_label_frame, text="Sell", command=lambda s=stock: on_sell(s), font=("Sabon", 12), bg="red", fg="white")
            sell_button.pack(side=tk.LEFT, padx=10)

def login():
    global api_key, username, pwd, smartApi
    from dotenv import load_dotenv
    if os.path.exists(".env"):
        load_dotenv()
        api_key = os.getenv("api_key")
        username = os.getenv("clientcode")
        pwd = os.getenv("pwd")
    else:
       print(f"\033[1;31m.env file not found\033[0m")
       sys.exit()
    smartApi = SmartConnect(api_key)    
    try:
        token = os.getenv("token")
        totp = pyotp.TOTP(token).now()
    except Exception as e:
        logger.error("Invalid Token: The provided token is not valid.")
        raise e

    correlation_id = "abcde"
    data = smartApi.generateSession(username, pwd, totp)

    if data['status'] == False:
        logger.error(data['message'])
    

    else:
        authToken = data['data']['jwtToken']
        refreshToken = data['data']['refreshToken']
        feedToken = smartApi.getfeedToken()
        res = smartApi.getProfile(refreshToken)
        smartApi.generateToken(refreshToken)
        res=res['data']['exchanges']
        logger.info("Login Successful!")
    
def logout():
    try:
        logout=smartApi.terminateSession(username)
        logger.info("Logout Successful")
    except Exception as e:
        logger.exception(f"Logout failed: {e}")

def find_stockprice(stock):
    price = float(smartApi.ltpData("NSE", f"{stock}-EQ", get_symbol_token(stock))['data']['ltp'])
    return(price)

def find_quantity(stock):
    balance = float(smartApi.rmsLimit()['data']['availablecash'])
    qnt = (balance * 5)//(find_stockprice(stock))
    return(int(qnt))

def on_buy(stock):
    """Handle the buy action for a stock."""
    print(f"Buying stock: {stock}")
    symboltoken = get_symbol_token(stock)
    if float(smartApi.rmsLimit()['data']['availablecash']) > find_stockprice(stock):
        # Implement your logic for buying the stock here
        try:
            orderparams = {
            "variety": "NORMAL",
            "tradingsymbol": f"{stock}-EQ",
            "symboltoken": symboltoken,
            "transactiontype": "BUY",
            "exchange": "NSE",
            "ordertype": "MARKET",
            "producttype": "INTRADAY",
            "duration": "DAY",
            "squareoff": ((find_quantity(stock) * find_stockprice(stock))*0.008),
            "stoploss": ((find_quantity(stock) * find_stockprice(stock))*0.003),
            "quantity": find_quantity(stock)
            }
            orderid = smartApi.placeOrder(orderparams)
            logger.info(f"PlacedOrder : {orderid}")
        except Exception as e:
            logger.exception(f"Order placement failed: {e}")
    else:
        print("\033[31mFunds not Sufficient\033[0m")

def on_sell(stock):
    """Handle the sell action for a stock."""
    print(f"Selling stock: {stock}")
    symboltoken = get_symbol_token(stock)
    if float(smartApi.rmsLimit()['data']['availablecash']) > find_stockprice(stock):
        # Implement your logic for buying the stock here
        try:
            orderparams = {
            "variety": "NORMAL",
            "tradingsymbol": f"{stock}-EQ",
            "symboltoken": symboltoken,
            "transactiontype": "SELL",
            "exchange": "NSE",
            "ordertype": "MARKET",
            "producttype": "INTRADAY",
            "duration": "DAY",
            "squareoff": ((find_quantity(stock) * find_stockprice(stock))*0.008),
            "stoploss": ((find_quantity(stock) * find_stockprice(stock))*0.003),
            "quantity": find_quantity(stock)
            }
            orderid = smartApi.placeOrder(orderparams)
            logger.info(f"PlacedOrder : {orderid}")
        except Exception as e:
            logger.exception(f"Order placement failed: {e}")

    else:
        print("\033[31mFunds not Sufficient\033[0m")

def main():
    global root, buying_frame, selling_frame

    # Initialize the GUI
    root = tk.Tk()
    root.title("Stock Market Analysis")
    root.geometry("800x600")

    # Create frames for buying and selling
    buying_frame = tk.Frame(root, bg="lightgreen", padx=10, pady=10)
    buying_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    selling_frame = tk.Frame(root, bg="lightcoral", padx=10, pady=10)
    selling_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)


    refresh_data()

    # Run the GUI loop
    root.mainloop()



login()
main()

import atexit
atexit.register(logout)
