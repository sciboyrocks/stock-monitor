__title__ = "smartapi-python"
__description__ = "Angel Broking openApi integration"
__url__ = "https://www.angelbroking.com/"
__download_url__ = "https://github.com/angel-one/smartapi-python"
__version__ = "1.5.2"
__author__ = "ab-smartapi"
__token__ = "ab-smartapi"
__author_email__ = "smartapi.sdk@gmail.com"


# [pypi]
# username = __token__
# password = pypi-AgEIcHlwaS5vcmcCJDkwNzYwNzU1LWMwOTUtNGNkOC1iYjQzLTU3OWNhZjI1NDQ1MwACJXsicGVybWlzc2lvbnMiOiAidXNlciIsICJ2ZXJzaW9uIjogMX0AAAYgSpW5PAywXvchMUQnkF5H6-SolJysfUvIWopMsxE4hCM
